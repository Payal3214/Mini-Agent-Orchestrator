"""
A tiny in-memory "database" for jobs.

Why in-memory: this is a take-home-sized service and the assignment
cares about orchestration logic, not persistence engineering. The store
is isolated behind a small async-safe interface so swapping it for
Redis/Postgres later means touching only this file.
"""
from __future__ import annotations

import asyncio

from app.models import JobRecord

_jobs: dict[str, JobRecord] = {}
_lock = asyncio.Lock()


async def create(job: JobRecord) -> None:
    async with _lock:
        _jobs[job.job_id] = job


async def get(job_id: str) -> JobRecord | None:
    async with _lock:
        job = _jobs.get(job_id)
        # return a copy so callers can't mutate our state accidentally
        return job.model_copy(deep=True) if job else None


async def save(job: JobRecord) -> None:
    async with _lock:
        _jobs[job.job_id] = job
