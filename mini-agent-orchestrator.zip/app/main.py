"""
API layer.

POST /process
    Accepts a natural language request. Plans it, kicks off async
    execution as a background asyncio task, and immediately returns a
    job_id + PENDING status (event-driven style).
    Pass ?sync=true to instead await full completion and get the final
    result in one response (handy for quick curl demos).

GET /jobs/{job_id}
    Poll for live status / final result.
"""
from __future__ import annotations

import asyncio

from fastapi import FastAPI, HTTPException

from app import job_store, orchestrator
from app.models import JobRecord, JobStatus, ProcessRequest
from app.planner import PlannerError, create_plan

app = FastAPI(
    title="Mini Agent Orchestrator",
    description="Event-driven order-processing agent: NL request -> plan -> async tool execution.",
    version="1.0.0",
)


@app.get("/")
async def root():
    return {"status": "ok", "service": "mini-agent-orchestrator"}


@app.post("/process")
async def process(payload: ProcessRequest, sync: bool = False):
    job = JobRecord(user_request=payload.request)

    try:
        job.plan = await create_plan(payload.request)
    except PlannerError as exc:
        # A planning failure never reaches the orchestrator; return a
        # clean 422 rather than a stack trace.
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    await job_store.create(job)

    if sync:
        await orchestrator.run_job(job.job_id)
        final = await job_store.get(job.job_id)
        return final

    # Fire-and-forget: the request returns immediately while the job
    # keeps running concurrently. This is the "event-driven" execution
    # path — orchestrator.run_job pushes state updates into the store
    # as each step completes, independent of this HTTP request/response cycle.
    asyncio.create_task(orchestrator.run_job(job.job_id))
    return {"job_id": job.job_id, "status": JobStatus.PENDING, "plan_source": job.plan.source}


@app.get("/jobs/{job_id}")
async def get_job(job_id: str):
    job = await job_store.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job
