"""
Data models shared across the app.

Kept deliberately small and explicit (no ORMs, no magic) so the
whole data flow can be understood by reading this one file.
"""
from __future__ import annotations

import uuid
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Inbound request
# ---------------------------------------------------------------------------
class ProcessRequest(BaseModel):
    request: str = Field(
        ...,
        description="Natural language instruction from the user.",
        examples=["Cancel my order #9921 and email me the confirmation at user@example.com."],
    )


# ---------------------------------------------------------------------------
# Plan produced by the Planner (LLM or mock)
# ---------------------------------------------------------------------------
class PlanStep(BaseModel):
    step_id: str
    tool: str                              # must match a key in tools.TOOL_REGISTRY
    args: dict[str, Any] = Field(default_factory=dict)
    depends_on: Optional[str] = None       # step_id this step requires to have SUCCEEDED


class Plan(BaseModel):
    steps: list[PlanStep]
    source: str  # "llm" or "mock_fallback" — transparency about how the plan was made


# ---------------------------------------------------------------------------
# Job execution state (the orchestrator's source of truth)
# ---------------------------------------------------------------------------
class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class StepResult(BaseModel):
    step_id: str
    tool: str
    status: JobStatus
    output: Optional[dict[str, Any]] = None
    error: Optional[str] = None
    skipped_reason: Optional[str] = None


class JobRecord(BaseModel):
    job_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_request: str
    status: JobStatus = JobStatus.PENDING
    plan: Optional[Plan] = None
    step_results: list[StepResult] = Field(default_factory=list)
    final_message: Optional[str] = None
