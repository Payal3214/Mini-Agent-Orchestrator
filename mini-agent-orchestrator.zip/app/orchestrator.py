"""
The Orchestrator: executes a validated Plan against the real tool
registry, step by step, updating the JobRecord in the store as it goes
(this is what makes the API "event-driven" — a client can poll
GET /jobs/{id} at any time and see live progress, not just a final blob).

Core guardrail (per the assignment): if cancel_order fails, any step
that depends on it (directly or transitively) is skipped rather than
executed, and the job is marked FAILED with a clear message.
"""
from __future__ import annotations

from app import job_store
from app.models import JobRecord, JobStatus, StepResult
from app.tools import TOOL_REGISTRY


async def run_job(job_id: str) -> None:
    job = await job_store.get(job_id)
    if job is None:
        return  # nothing to do — job vanished/expired

    job.status = JobStatus.RUNNING
    await job_store.save(job)

    failed_step_ids: set[str] = set()

    for step in job.plan.steps:
        # Guardrail: if this step depends on a step that failed or was
        # itself skipped, do not execute it — cascade the skip instead.
        if step.depends_on and step.depends_on in failed_step_ids:
            result = StepResult(
                step_id=step.step_id,
                tool=step.tool,
                status=JobStatus.FAILED,
                skipped_reason=(
                    f"Skipped because prerequisite step '{step.depends_on}' failed."
                ),
            )
            job.step_results.append(result)
            failed_step_ids.add(step.step_id)
            await job_store.save(job)
            continue

        tool_fn = TOOL_REGISTRY[step.tool]
        try:
            output = await tool_fn(**step.args)
        except Exception as exc:  # a crashing tool must not crash the job
            result = StepResult(
                step_id=step.step_id,
                tool=step.tool,
                status=JobStatus.FAILED,
                error=str(exc),
            )
            job.step_results.append(result)
            failed_step_ids.add(step.step_id)
            await job_store.save(job)
            continue

        succeeded = bool(output.get("success"))
        result = StepResult(
            step_id=step.step_id,
            tool=step.tool,
            status=JobStatus.SUCCEEDED if succeeded else JobStatus.FAILED,
            output=output,
        )
        job.step_results.append(result)
        if not succeeded:
            failed_step_ids.add(step.step_id)
        await job_store.save(job)

    _finalize(job)
    await job_store.save(job)


def _finalize(job: JobRecord) -> None:
    if any(r.status == JobStatus.FAILED for r in job.step_results):
        job.status = JobStatus.FAILED
        failure = next(r for r in job.step_results if r.status == JobStatus.FAILED)
        reason = failure.error or failure.skipped_reason or (
            failure.output.get("message") if failure.output else "Unknown failure."
        )
        job.final_message = f"Request failed at step '{failure.step_id}' ({failure.tool}): {reason}"
    else:
        job.status = JobStatus.SUCCEEDED
        job.final_message = "All steps completed successfully."
