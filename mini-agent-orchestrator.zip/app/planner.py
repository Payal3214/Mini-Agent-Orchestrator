"""
The Planner turns a natural language request into a validated Plan
(a list of PlanStep objects the orchestrator can execute).

Two paths, chosen automatically:
  1. If OPENAI_API_KEY is set -> ask the real OpenAI API for a JSON plan.
  2. Otherwise (or if the LLM call/response is bad) -> fall back to a
     deterministic regex-based mock planner, so the service is fully
     runnable and demoable with zero API keys.

Either way, the output is passed through `_validate_plan`, which is the
real guardrail: it rejects unknown tools, missing required args, and
bad dependency references *before* anything reaches the orchestrator.
"""
from __future__ import annotations

import json
import os
import re
import uuid

from app.models import Plan, PlanStep
from app.tools import TOOL_REGISTRY

# Minimal, explicit schema the LLM must satisfy. Kept as plain Python
# (not a heavy framework) since the assignment asks us to build the
# logic ourselves rather than lean on LangChain-style abstractions.
REQUIRED_ARGS = {
    "cancel_order": {"order_id"},
    "send_email": {"email", "message"},
}

SYSTEM_PROMPT = """You are a planning module for an order-processing agent.
Given a user's natural language request, output ONLY valid JSON (no prose,
no markdown fences) matching this schema:

{
  "steps": [
    {"step_id": "s1", "tool": "cancel_order", "args": {"order_id": "<id>"}},
    {"step_id": "s2", "tool": "send_email", "args": {"email": "<email>", "message": "<short confirmation text>"}, "depends_on": "s1"}
  ]
}

Rules:
- Only use tools from this list: cancel_order, send_email.
- Only include a send_email step if the user gave an email address AND asked to be emailed/notified/confirmed.
- If a step must only run after another step succeeds, set "depends_on" to that step's step_id.
- Every order id and email address must be copied exactly as given by the user.
- Output must be a single JSON object and nothing else.
"""


class PlannerError(Exception):
    pass


async def create_plan(user_request: str) -> Plan:
    api_key = os.environ.get("OPENAI_API_KEY")

    if api_key:
        try:
            raw_steps = await _plan_with_openai(user_request, api_key)
            return _validate_plan(raw_steps, source="llm")
        except Exception:
            # LLM unreliability guardrail: never let a bad/unavailable model
            # response take the whole request down. Fall back to the
            # deterministic parser instead.
            pass

    raw_steps = _plan_with_mock(user_request)
    return _validate_plan(raw_steps, source="mock_fallback")


# ---------------------------------------------------------------------------
# Real LLM path
# ---------------------------------------------------------------------------
async def _plan_with_openai(user_request: str, api_key: str) -> list[dict]:
    from openai import AsyncOpenAI  # imported lazily so the package is optional

    client = AsyncOpenAI(api_key=api_key)

    response = await client.chat.completions.create(
        model="gpt-4o-mini",
        temperature=0,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_request},
        ],
    )

    content = response.choices[0].message.content
    data = json.loads(content)  # raises if the model didn't return valid JSON
    steps = data.get("steps")
    if not isinstance(steps, list):
        raise PlannerError("LLM response missing a 'steps' list")
    return steps


# ---------------------------------------------------------------------------
# Deterministic fallback / offline mode
# ---------------------------------------------------------------------------
def _plan_with_mock(user_request: str) -> list[dict]:
    text = user_request.strip()

    order_match = re.search(r"#\s?(\w+)", text) or re.search(
        r"order\s+(?:id\s+)?(\w+)", text, re.IGNORECASE
    )
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w-]+(?:\.[\w-]+)*", text)

    steps: list[dict] = []
    wants_cancel = "cancel" in text.lower()
    wants_email = bool(email_match) and any(
        kw in text.lower() for kw in ("email", "confirmation", "notify", "confirm")
    )

    cancel_step_id = "s1"
    if wants_cancel and order_match:
        steps.append(
            {
                "step_id": cancel_step_id,
                "tool": "cancel_order",
                "args": {"order_id": order_match.group(1)},
            }
        )

    if wants_email:
        steps.append(
            {
                "step_id": "s2",
                "tool": "send_email",
                "args": {
                    "email": email_match.group(0),
                    "message": (
                        f"Your order {order_match.group(1)} has been cancelled."
                        if order_match
                        else "Your request has been processed."
                    ),
                },
                "depends_on": cancel_step_id if steps else None,
            }
        )

    if not steps:
        raise PlannerError(
            "Could not extract any actionable step from the request. "
            "Try including an order id (e.g. #9921) and/or an email address."
        )

    return steps


# ---------------------------------------------------------------------------
# Shared validation guardrail
# ---------------------------------------------------------------------------
def _validate_plan(raw_steps: list[dict], source: str) -> Plan:
    if not raw_steps:
        raise PlannerError("Plan has no steps.")

    seen_ids: set[str] = set()
    validated: list[PlanStep] = []

    for raw in raw_steps:
        tool = raw.get("tool")
        if tool not in TOOL_REGISTRY:
            raise PlannerError(f"Unknown tool in plan: {tool!r}")

        args = raw.get("args") or {}
        missing = REQUIRED_ARGS[tool] - set(args.keys())
        if missing:
            raise PlannerError(f"Step for {tool!r} missing required args: {missing}")

        step_id = raw.get("step_id") or f"s_{uuid.uuid4().hex[:6]}"
        depends_on = raw.get("depends_on")
        if depends_on and depends_on not in seen_ids:
            raise PlannerError(
                f"Step {step_id!r} depends_on {depends_on!r}, which is not an earlier step."
            )

        seen_ids.add(step_id)
        validated.append(
            PlanStep(step_id=step_id, tool=tool, args=args, depends_on=depends_on)
        )

    return Plan(steps=validated, source=source)
