"""
The agent's "hands" — the actual actions it can take.

Each tool is an async function with a plain (str, ...) -> dict signature.
TOOL_REGISTRY is the single whitelist the orchestrator is allowed to call
from — this is the main guardrail against a hallucinated or malformed
LLM plan invoking something it shouldn't.
"""
from __future__ import annotations

import asyncio
import random


async def cancel_order(order_id: str) -> dict:
    """
    Mock order cancellation.

    Simulates a backend call with latency + a random 20% failure rate,
    exactly as required by the assignment.
    """
    await asyncio.sleep(0.3)  # pretend network/db latency

    if random.random() < 0.2:
        return {
            "success": False,
            "order_id": order_id,
            "message": f"Order {order_id} could not be cancelled (simulated backend failure).",
        }

    return {
        "success": True,
        "order_id": order_id,
        "message": f"Order {order_id} was cancelled successfully.",
    }


async def send_email(email: str, message: str) -> dict:
    """
    Mock email send. Always "succeeds" after a 1-second simulated send time.
    """
    await asyncio.sleep(1)
    return {
        "success": True,
        "email": email,
        "message": f"Email sent to {email}.",
        "body_preview": message,
    }


# Whitelist the orchestrator dispatches against. Adding a new tool means
# adding it here AND telling the planner prompt about it — nothing else
# in the codebase needs to change.
TOOL_REGISTRY = {
    "cancel_order": cancel_order,
    "send_email": send_email,
}
