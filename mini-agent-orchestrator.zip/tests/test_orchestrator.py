import asyncio

import pytest

from app import job_store, orchestrator, tools
from app.models import JobRecord, JobStatus, Plan, PlanStep
from app.planner import _plan_with_mock, _validate_plan, create_plan


@pytest.mark.asyncio
async def test_mock_planner_extracts_order_and_email():
    steps = _plan_with_mock(
        "Cancel my order #9921 and email me the confirmation at user@example.com."
    )
    plan = _validate_plan(steps, source="mock_fallback")
    tool_names = [s.tool for s in plan.steps]
    assert tool_names == ["cancel_order", "send_email"]
    assert plan.steps[0].args["order_id"] == "9921"
    assert plan.steps[1].args["email"] == "user@example.com"
    assert plan.steps[1].depends_on == plan.steps[0].step_id


@pytest.mark.asyncio
async def test_orchestrator_skips_email_when_cancel_fails(monkeypatch):
    async def always_fail(order_id: str):
        return {"success": False, "order_id": order_id, "message": "boom"}

    monkeypatch.setitem(tools.TOOL_REGISTRY, "cancel_order", always_fail)

    plan = Plan(
        steps=[
            PlanStep(step_id="s1", tool="cancel_order", args={"order_id": "1"}),
            PlanStep(
                step_id="s2",
                tool="send_email",
                args={"email": "a@b.com", "message": "hi"},
                depends_on="s1",
            ),
        ],
        source="mock_fallback",
    )
    job = JobRecord(user_request="test", plan=plan)
    await job_store.create(job)

    await orchestrator.run_job(job.job_id)

    final = await job_store.get(job.job_id)
    assert final.status == JobStatus.FAILED
    email_result = [r for r in final.step_results if r.tool == "send_email"][0]
    assert email_result.status == JobStatus.FAILED
    assert email_result.skipped_reason is not None


@pytest.mark.asyncio
async def test_orchestrator_succeeds_when_cancel_succeeds(monkeypatch):
    async def always_succeed(order_id: str):
        return {"success": True, "order_id": order_id, "message": "ok"}

    monkeypatch.setitem(tools.TOOL_REGISTRY, "cancel_order", always_succeed)

    plan = Plan(
        steps=[
            PlanStep(step_id="s1", tool="cancel_order", args={"order_id": "1"}),
            PlanStep(
                step_id="s2",
                tool="send_email",
                args={"email": "a@b.com", "message": "hi"},
                depends_on="s1",
            ),
        ],
        source="mock_fallback",
    )
    job = JobRecord(user_request="test", plan=plan)
    await job_store.create(job)

    await orchestrator.run_job(job.job_id)

    final = await job_store.get(job.job_id)
    assert final.status == JobStatus.SUCCEEDED
    assert all(r.status == JobStatus.SUCCEEDED for r in final.step_results)


@pytest.mark.asyncio
async def test_planner_rejects_unknown_tool():
    from app.planner import PlannerError

    with pytest.raises(PlannerError):
        _validate_plan([{"step_id": "s1", "tool": "delete_database", "args": {}}], source="llm")
